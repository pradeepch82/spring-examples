package com.amazonaws.samples;

public class SimpleAWSConnection {
public static void main(String[] args) {
	
}
	
}
