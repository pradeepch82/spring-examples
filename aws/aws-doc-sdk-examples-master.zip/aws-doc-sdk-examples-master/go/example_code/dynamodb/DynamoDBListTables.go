// snippet-comment:[These are tags for the AWS doc team's sample catalog. Do not remove.]
// snippet-sourceauthor:[Doug-AWS]
// snippet-sourcedescription:[DynamoDBListTables.go lists your Amazon DynamoDB tables.]
// snippet-keyword:[Amazon DynamoDB]
// snippet-keyword:[ListTables function]
// snippet-keyword:[Go]
// snippet-sourcesyntax:[go]
// snippet-service:[dynamodb]
// snippet-keyword:[Code Sample]
// snippet-sourcetype:[full-example]
// snippet-sourcedate:[2019-05-3]
/*
   Copyright 2010-2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.

   This file is licensed under the Apache License, Version 2.0 (the "License").
   You may not use this file except in compliance with the License. A copy of
   the License is located at

    http://aws.amazon.com/apache2.0/

   This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied. See the License for the
   specific language governing permissions and limitations under the License.
*/
// snippet-start:[dynamodb.go.list_tables]
package main

// snippet-start:[dynamodb.go.list_tables.imports]
import (
    "github.com/aws/aws-sdk-go/aws/awserr"
    "github.com/aws/aws-sdk-go/aws/session"
    "github.com/aws/aws-sdk-go/service/dynamodb"

    "fmt"
)

// snippet-end:[dynamodb.go.list_tables.imports]

func main() {
    // snippet-start:[dynamodb.go.list_tables.session]
    // Initialize a session that the SDK will use to load
    // credentials from the shared credentials file ~/.aws/credentials
    // and region from the shared configuration file ~/.aws/config.
    sess := session.Must(session.NewSessionWithOptions(session.Options{
        SharedConfigState: session.SharedConfigEnable,
    }))

    // Create DynamoDB client
    svc := dynamodb.New(sess)
    // snippet-end:[dynamodb.go.list_tables.session]

    // snippet-start:[dynamodb.go.list_tables.call]
    // create the input configuration instance
    input := &dynamodb.ListTablesInput{}

    fmt.Printf("Tables:\n")

    for {
        // Get the list of tables
        result, err := svc.ListTables(input)
        if err != nil {
            if aerr, ok := err.(awserr.Error); ok {
                switch aerr.Code() {
                case dynamodb.ErrCodeInternalServerError:
                    fmt.Println(dynamodb.ErrCodeInternalServerError, aerr.Error())
                default:
                    fmt.Println(aerr.Error())
                }
            } else {
                // Print the error, cast err to awserr.Error to get the Code and
                // Message from an error.
                fmt.Println(err.Error())
            }
            return
        }

        for _, n := range result.TableNames {
            fmt.Println(*n)
        }

        // assign the last read tablename as the start for our next call to the ListTables function
        // the maximum number of table names returned in a call is 100 (default), which requires us to make
        // multiple calls to the ListTables function to retrieve all table names
        input.ExclusiveStartTableName = result.LastEvaluatedTableName

        if result.LastEvaluatedTableName == nil {
            break
        }
    }
    // snippet-end:[dynamodb.go.list_tables.call]
}

// snippet-end:[dynamodb.go.list_tables]
