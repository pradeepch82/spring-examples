package com.mphasis.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.entity.Student;
import com.mphasis.service.StudentService;

@RestController
@RequestMapping("/api")
public class StudentRestController {

	private final Logger logger = LoggerFactory.getLogger(StudentRestController.class);

	@Autowired
	private StudentService studentService;

	@GetMapping("/students")
	public List<Student> findAll() {
		logger.debug("  StudentRestController  findAllStudent : /students");

		return studentService.findAllStudents();
	}

	
	
	@GetMapping("/students/{id}")
	@Cacheable(value = "students",key="#id",unless ="#result.id>101")
	public Student findStudent(@PathVariable Integer id) {
		logger.debug("  StudentRestController  findStudent : /students/{} " + id);

		return studentService.findStudent(id);
	}

	@ResponseStatus(value = HttpStatus.OK)
	@DeleteMapping("/students/{id}")
	@CacheEvict(value = "students", allEntries = false, key="#id")
	public void deleteStudent(@PathVariable Integer id) {
		logger.debug("  StudentRestController  deleteStudent :/students/{} " + id);

		studentService.deleteStudent(id);
	}

	@ResponseStatus(value = HttpStatus.OK)
	@PutMapping("/students/{id}")
    //@CachePut(value = "students",key = "#student.id")
	public Student updateStudent(@PathVariable Integer id, @RequestBody Student student) {
		logger.debug("  StudentRestController  updateStudent :  /students/{} " + id);

		studentService.updateStudent(student);
		return student;
	}
	
	@ResponseStatus(value = HttpStatus.CREATED)
	@PostMapping("/students")
	public Student addStudent(@RequestBody Student student) {
		logger.debug("  StudentRestController  addStudent : /students/ " + student);
		return studentService.saveStudent(student);
	}

}
