package com.mphasis.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.controller.StudentRestController;
import com.mphasis.dao.StudentRepository;
import com.mphasis.entity.Student;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository;
	private final Logger logger = LoggerFactory.getLogger(StudentServiceImpl.class);


	@Override
	public Student saveStudent(Student student) {
		logger.debug(" >> StudentServiceImpl : Entering saveStudent");
        logger.debug(" << StudentServiceImpl : Exiting saveStudent");

		return studentRepository.save(student);
	}

	@Override
	public boolean updateStudent(Student student) {
		logger.debug(" >> StudentServiceImpl : Entering updateStudent");
        logger.debug(" << StudentServiceImpl : Exiting updateStudent");

		if (studentRepository.existsById(student.getId()))
			return studentRepository.save(student) == student;
		return false;
	}

	@Override
	public boolean deleteStudent(Integer studentId) {
		logger.debug(" >> StudentServiceImpl : Entering deleteStudent");
        logger.debug(" << StudentServiceImpl : Exiting deleteStudent");

		if (studentRepository.existsById(studentId)) {
			studentRepository.deleteById(studentId);
			return true;
		}
		return false;
	}

	@Override
	public Student findStudent(Integer studentId) {
		logger.debug(" >> StudentServiceImpl : Entering findStudent");
        logger.debug(" << StudentServiceImpl : Exiting findStudent");

		return studentRepository.findById(studentId).orElse(new Student());
	}

	@Override
	public List<Student> findAllStudents() {
		logger.debug(" >> StudentServiceImpl : Entering findAllStudents");
        logger.debug(" << StudentServiceImpl : Exiting findAllStudents");

		List<Student> students = new ArrayList<>();
		studentRepository.findAll().forEach(students::add);

		return students;
	}

}
