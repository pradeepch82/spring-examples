package com.mphasis.service;

import java.util.List;

import com.mphasis.entity.Student;

public interface StudentService {

	Student saveStudent(Student student);

	boolean updateStudent(Student student);

	boolean deleteStudent(Integer studentId);

	Student findStudent(Integer studentId);

	List<Student> findAllStudents();
}
