package com.mphasis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import com.mphasis.dao.StudentRepository;
import com.mphasis.entity.Student;

@EnableCaching
@SpringBootApplication
public class SpringBootExampleRedisApplication implements CommandLineRunner {

	@Autowired
	private StudentRepository studentRepository;

	public static void main(String[] args) {
		SpringApplication.run(SpringBootExampleRedisApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {


		System.out.println("Inserting students");
		System.out.println("===============================");
	
		Student student1 = new Student(101, "Ram", Student.Gender.MALE, 1);
		Student student2 = new Student(102, "Rahim", Student.Gender.MALE, 2);
		Student student3 = new Student(103, "David", Student.Gender.MALE, 3);
	
		studentRepository.save(student1);
		studentRepository.save(student2);
        studentRepository.save(student3);
		}
	
}
