package com.example.configclient;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DBController {
	
	@Value("${jdbc.username}")
	String uname;
	
	@Value("${jdbc.password}")
	String password;
	
	@Value("${jdbc.url}")
	String url;	
	

	@GetMapping("/db")
	public String getProperties()
	{
		Map<String,String> mymap=new HashMap<>();
		mymap.put("username", uname);
		mymap.put("url", url);
		mymap.put("password", password);
		return mymap.toString();
	}	

	/*
	 * @Value("${msg}") String msg;
	 * 
	 * @RequestMapping(value="/dbqa",method= RequestMethod.GET ) public String
	 * getQAProperties() { Map<String,String> mymap=new HashMap<>();
	 * mymap.put("msg", msg);
	 * 
	 * return mymap.toString(); }
	 */
}
