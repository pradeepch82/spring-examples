package com.pradeep.zuulproxy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulProxyApplicationTests {

	@Test
	void contextLoads() {
	}

}
